_base_ = ['../_base_/sac/sac_mani_skill_mlp.py']
