# The full training data with simulation state should be stored here.
Demonstration data should be stored under "OpenCabinetDrawer", "OpenCabinetDoor", "MoveBucket", and "PushChair".
