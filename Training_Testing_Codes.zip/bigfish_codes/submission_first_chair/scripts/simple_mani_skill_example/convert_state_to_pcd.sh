python tools/convert_state.py --max-num-traj=-1 --env-name=OpenCabinetDrawer_1045_link_0-v0 \
--traj-name=./example_mani_skill_data/OpenCabinetDrawer_1045_link_0-v0_state.h5 \
--output-name=./example_mani_skill_data/OpenCabinetDrawer_1045_link_0-v0_pcd.h5
