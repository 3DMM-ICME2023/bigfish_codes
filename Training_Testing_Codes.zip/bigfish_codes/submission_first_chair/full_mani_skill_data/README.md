# The full training data and pre-trained model should be stored here.
Demonstration data should be stored under "OpenCabinetDrawer", "OpenCabinetDoor", "MoveBucket", and "PushChair".

Model checkpoint should be stored under the "models" directory, e.g. 'models/OpenCabinetDoor-v0_PN_Transformer.ckpt".
