PYTHONPATH=/export/home/liukun/submission_first:$PYTHONPATH python mani_skill/tools/evaluate_policy.py --env OpenCabinetDrawer_1045_link_0-v0
