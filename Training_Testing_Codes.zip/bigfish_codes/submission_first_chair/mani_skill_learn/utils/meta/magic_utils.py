# https://github.com/alexmojaki/sorcery
from sorcery import dict_of
