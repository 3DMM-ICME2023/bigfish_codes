from .split_array import split_num
