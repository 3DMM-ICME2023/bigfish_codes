from .deterministic import DeterministicHead
from .gaussian import GaussianHead

